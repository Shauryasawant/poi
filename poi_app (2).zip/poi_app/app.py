from flask import Flask, jsonify, request, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import urllib.parse
from datetime import datetime, date
import random

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# URL encode the password to handle special characters
password = urllib.parse.quote_plus("Sus10@wwe") 
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://root:{password}@localhost/poi_data'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class POI(db.Model):
    __tablename__ = 'poi_data'  # Your actual table name
    id = db.Column(db.Integer, primary_key=True)
    official_name = db.Column(db.String(255))  # Changed to match the actual column name
    address = db.Column('unparsed_address', db.String(255))  # Changed to match actual column
    # Replace coordinates with separate latitude and longitude fields
    display_latitude = db.Column(db.Float)
    display_longitude = db.Column(db.Float)
    primary_category = db.Column(db.String(100))
    


class POISubmission(db.Model):
    __tablename__ = 'poi_submissions'
    id = db.Column(db.Integer, primary_key=True)
    poi_name = db.Column(db.String(255))
    reference_url = db.Column(db.Text)
    timestamp = db.Column(db.DateTime)
    
    # Add relationships to store answers
    answers = db.relationship('POIAnswer', backref='submission', lazy=True)


class POIAnswer(db.Model):
    __tablename__ = 'poi_answers'
    id = db.Column(db.Integer, primary_key=True)
    submission_id = db.Column(db.Integer, db.ForeignKey('poi_submissions.id'))
    question = db.Column(db.Text)
    answer = db.Column(db.String(50))


# New model for storing questions
class Question(db.Model):
    __tablename__ = 'questions'
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    options = db.Column(db.Text)  # Store as JSON or comma-separated values if needed


# New model for daily questions
class DailyQuestion(db.Model):
    __tablename__ = 'daily_questions'
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True)
    question_ids = db.Column(db.String(50), nullable=False)  # Store as comma-separated IDs


def get_or_create_daily_questions():
    """Get the questions for today or create them if they don't exist"""
    today = date.today()
    
    # Check if we already have questions for today
    daily_question = DailyQuestion.query.filter_by(date=today).first()
    
    if daily_question:
        # We already have questions for today
        question_ids = [int(id) for id in daily_question.question_ids.split(',')]
        questions = Question.query.filter(Question.id.in_(question_ids)).all()
    else:
        # We need to select new questions for today
        all_questions = Question.query.all()
        if len(all_questions) < 3:
            # Not enough questions in the database
            # You might want to have some default questions
            raise Exception("Not enough questions in database")
        
        # Randomly select 3 questions
        selected_questions = random.sample(all_questions, 3)
        questions = selected_questions
        
        # Save these questions for today
        question_ids = ','.join([str(q.id) for q in selected_questions])
        new_daily = DailyQuestion(date=today, question_ids=question_ids)
        db.session.add(new_daily)
        db.session.commit()
    
    return questions


@app.route('/')
def index():
    # Redirect to start page instead of rendering index.html directly
    return redirect(url_for('start_page'))


@app.route('/api/poi/names', methods=['GET'])
def get_poi_names():
    try:
        # Fetch all POI names
        pois = POI.query.all()
        poi_list = [
            {
                'Official Name': poi.official_name,
                'address': poi.address,
                'Display Latitude': poi.display_latitude,
                'Display Longitude': poi.display_longitude,
                'primary_category': poi.primary_category
            } for poi in pois
        ]
        return jsonify(poi_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# New endpoint to get today's questions
@app.route('/api/questions/daily', methods=['GET'])
def get_daily_questions():
    try:
        questions = get_or_create_daily_questions()
        question_list = []
        
        for q in questions:
            question_data = {
                'id': q.id,
                'text': q.text
            }
            
            # Parse options if available
            if q.options:
                # Assuming options are stored as comma-separated values
                question_data['options'] = q.options.split(',')
            
            question_list.append(question_data)
            
        return jsonify(question_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/poi/submit', methods=['POST'])
def submit_poi_data():
    try:
        data = request.json
        
        # Create a new submission record
        submission = POISubmission(
            poi_name=data['poiName'],
            reference_url=data['referenceUrl'],
            timestamp=datetime.fromisoformat(data['timestamp'])
        )
        db.session.add(submission)
        db.session.flush()  # To get the submission ID
        
        # Add all the answers
        for response in data['responses']:
            answer = POIAnswer(
                submission_id=submission.id,
                question=response['question'],
                answer=response['answer']
            )
            db.session.add(answer)
        
        db.session.commit()
        return jsonify({'status': 'success'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/start')
def start_page():
    """Render the start page for POI data collection"""
    return render_template('start.html')


@app.route('/poi-quiz')
def poi_quiz():
    """Render the POI quiz page with time tracking"""
    # You could add session-based tracking here if needed
    return render_template('index.html')


@app.route('/api/poi/complete', methods=['POST'])
def complete_poi():
    """Mark a POI as completed and update daily limits"""
    try:
        data = request.json
        poi_id = data.get('poi_id')
        
        # Here you would save the completion to the database
        # This example just returns success
        return jsonify({
            'status': 'success',
            'message': 'POI task completed'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/poi/user-stats', methods=['GET'])
def get_user_stats():
    """Get user's current stats (completed tasks, time remaining)"""
    # In a real implementation, you would fetch this from your database
    # or user session instead of sending dummy data
    return jsonify({
        'completedTasks': 0,
        'timeRemaining': 300,  # 5 minutes in seconds
        'dailyLimit': 3
    })


@app.route('/end')
def end_page():
    """Render the session end page."""
    # You could potentially pass data here via query params or session
    # if you wanted to display specific messages (e.g., "Time's up" vs "Limit reached")
    # For now, a generic end page is fine.
    return render_template('end.html')


# Add this utility function to populate the question database if needed
def populate_sample_questions():
    """Helper function to add sample questions to the database"""
    # Only run if there are no questions
    if Question.query.count() == 0:
        sample_questions = [
            {"text": "Is this location accessible by public transportation?", "options": "Yes,No,Unknown"},
            {"text": "Does this location have wheelchair access?", "options": "Yes,No,Unknown"},
            {"text": "Is this location currently open?", "options": "Yes,No,Unknown"},
            {"text": "Does this location have parking available?", "options": "Yes,No,Unknown"},
            {"text": "Is this location free to visit?", "options": "Yes,No,Unknown"},
            {"text": "Does this location have restrooms?", "options": "Yes,No,Unknown"},
            {"text": "Is this location suitable for children?", "options": "Yes,No,Unknown"},
            {"text": "Does this location serve food?", "options": "Yes,No,Unknown"},
            {"text": "Does this location require reservations?", "options": "Yes,No,Unknown"}
        ]
        
        for q in sample_questions:
            new_question = Question(text=q["text"], options=q["options"])
            db.session.add(new_question)
        
        db.session.commit()
        print("Added sample questions to the database.")


if __name__ == '__main__':
    # Create tables if they don't exist
    with app.app_context():
        db.create_all()
        # Uncomment the line below to add sample questions on first run
        populate_sample_questions()
    app.run(debug=True)