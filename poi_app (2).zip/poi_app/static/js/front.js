
// --- POI Data Management Class ---

class POIDataManager {
    
    constructor() {
        this.poiList = [];
        this.currentIndex = 0;
        this.submittedAnswers = {}; // Store answers for potential revisit
        this.timerInterval = null;
        this.dailyData = null; // Will be loaded from localStorage

        // Load daily data immediately
        this.loadDailyData();
    }

    loadDailyData() {
        let storedData = localStorage.getItem('poiDailyData');
        if (storedData) {
            this.dailyData = JSON.parse(storedData);
            console.log('Loaded daily data:', this.dailyData);
            
            // Load the current POI index from localStorage to maintain state across reloads
            const storedIndex = localStorage.getItem('currentPOIIndex');
            if (storedIndex !== null) {
                this.currentIndex = parseInt(storedIndex, 10);
                console.log('Restored POI index from localStorage:', this.currentIndex);
            }

            // Check if the session should be active
            if (this.dailyData.active && this.dailyData.timeRemaining > 0) {
                // Start or resume the timer
                this.startTimer();
                // Update display immediately in case page was reloaded
                this.updateTimerDisplay();
            } else if (this.dailyData.active && this.dailyData.timeRemaining <= 0) {
                 // If localStorage says active but time is zero, force end
                 console.warn('Session marked active but time is zero. Ending session.');
                 this.dailyData.active = false;
                 localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
                 alert('Your previous session time had expired.');
                 window.location.href = '/end';
            }
        } else {
            // User likely landed on the quiz page directly, redirect to start page
            console.error('No daily data found in localStorage. Redirecting to start.');
            alert('Session data not found. Please start from the beginning.');
            window.location.href = '/start';
        }
    }

    startTimer() {
        // Ensure timer isn't already running
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }

        // Add timer display to UI if it doesn't exist
        if (!document.getElementById('session-timer')) {
            const timerDiv = document.createElement('div');
            timerDiv.id = 'session-timer';
            timerDiv.classList.add('session-timer');
            // Initialize with current remaining time
            const minutes = Math.floor(this.dailyData.timeRemaining / 60);
            const seconds = this.dailyData.timeRemaining % 60;
            timerDiv.innerHTML = `Time remaining: <span>${minutes}:${seconds < 10 ? '0' : ''}${seconds}</span>`;

            // Try to append to header, fallback to body start if header isn't specific enough
            const header = document.querySelector('.header') || document.body;
            header.style.position = 'relative'; // Ensure header can position absolute children
            header.appendChild(timerDiv);

            // Add CSS for the timer dynamically
            const style = document.createElement('style');
            style.textContent = `
                .session-timer {
                    position: absolute;
                    top: 10px;
                    right: 15px;
                    background: #e74c3c;
                    color: white;
                    padding: 6px 12px;
                    border-radius: 5px;
                    font-weight: bold;
                    font-size: 0.9em;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                }
            `;
            document.head.appendChild(style);
        }

        // Set up the interval
        this.timerInterval = setInterval(() => {
            if (this.dailyData.timeRemaining > 0) {
                this.dailyData.timeRemaining--;
                this.updateTimerDisplay();

                // Save to localStorage frequently
                localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
            }

            // Check if time is up
            if (this.dailyData.timeRemaining <= 0) {
                clearInterval(this.timerInterval); // Stop the timer

                // Mark session as inactive and save before redirecting
                this.dailyData.active = false;
                localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
                // Clear current POI index as well
                localStorage.removeItem('currentPOIIndex');

                alert('Your time is up! You will be redirected.');

                // Redirect to the end page
                window.location.href = '/end';
            }
        }, 1000); // 1 second interval
    }

    updateTimerDisplay() {
        const timerSpan = document.querySelector('#session-timer span');
        // Ensure timerSpan exists before trying to update
        if (timerSpan && this.dailyData) {
            const minutes = Math.floor(this.dailyData.timeRemaining / 60);
            const seconds = this.dailyData.timeRemaining % 60;
            timerSpan.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        } else if (!timerSpan) {
            console.error("Timer display span not found.");
        }
    }

    async fetchPOINames() {
        // Only fetch if the session is active and POIs aren't already loaded
        if (!this.dailyData || !this.dailyData.active) {
             console.log("Session not active, not fetching POIs.");
             // Redirect if somehow ended up here without active session
             if (!this.dailyData || !this.dailyData.active) window.location.href = '/start';
             return [];
        }
        if (this.poiList.length > 0) {
            console.log("POIs already fetched.");
            return this.poiList;
        }

        try {
            const response = await fetch('/api/poi/names');

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Response not OK:', response.status, errorText);
                throw new Error(`Failed to fetch POI names (Status: ${response.status})`);
            }

            const data = await response.json();
            console.log('Fetched POI data:', data);

            if (!Array.isArray(data)) {
                console.error('Invalid POI data format received:', data);
                throw new Error('Invalid POI data format');
            }

            this.poiList = data;
            
            // Initialize completedPOIs array if not exists
            if (!this.dailyData.completedPOIs) {
                this.dailyData.completedPOIs = [];
                localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
            }
            
            // Skip completed POIs if we have tracking data
            if (this.dailyData.completedPOIs && this.dailyData.completedPOIs.length > 0) {
                console.log('Checking for completed POIs to skip:', this.dailyData.completedPOIs);
                
                // Find the next uncompleted POI if we're continuing a session
                let foundUncompleted = false;
                
                // First check if the current index is already pointing to an uncompleted POI
                if (this.currentIndex < this.poiList.length) {
                    const currentPoi = this.poiList[this.currentIndex];
                    if (!this.dailyData.completedPOIs.includes(currentPoi['Official Name'])) {
                        foundUncompleted = true;
                        console.log('Current index points to uncompleted POI:', currentPoi['Official Name']);
                    }
                }
                
                // If current index points to a completed POI, find the next uncompleted one
                if (!foundUncompleted) {
                    for (let i = 0; i < this.poiList.length; i++) {
                        const poiName = this.poiList[i]['Official Name'];
                        if (!this.dailyData.completedPOIs.includes(poiName)) {
                            this.currentIndex = i;
                            localStorage.setItem('currentPOIIndex', this.currentIndex.toString());
                            console.log('Found uncompleted POI at index', i, ':', poiName);
                            foundUncompleted = true;
                            break;
                        }
                    }
                }
                
                // If all POIs are completed but daily limit not reached, notify the user
                if (!foundUncompleted && this.dailyData.completedTasks < (this.dailyData.dailyLimit || 3)) {
                    console.log('All POIs completed but daily limit not reached.');
                    alert('You have already completed all available POIs. Great job!');
                    
                    // Mark session inactive
                    this.dailyData.active = false;
                    localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
                    // Clear current POI index
                    localStorage.removeItem('currentPOIIndex');
                    
                    // Redirect to end page
                    setTimeout(() => {
                        window.location.href = '/end';
                    }, 1000);
                    
                    return [];
                }
            }
            
            return this.poiList;

        } catch (error) {
            console.error('Error fetching POI names:', error);
            alert('Error fetching POI data: ' + error.message + "\nPlease try refreshing or starting over.");
            // Deactivate session on fetch error
            this.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
            window.location.href = '/start'; // Redirect to start on critical fetch error
            return []; // Return empty list
        }
    }

    async submitPOIData(poiName, responses, referenceUrl, addressData) {
    // Validate session state
    if (!this.dailyData || !this.dailyData.active) {
        alert("Your session is no longer active. Redirecting.");
        window.location.href = '/end';
        return null;
    }

    // Cache submit button for loading state
    const submitButton = document.querySelector('.submit-button');
    if (!submitButton) {
        console.error("Submit button not found in DOM.");
    }

    // Set loading state
    if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = 'Submitting...';
    }

    // Store answers locally for potential revisit
    this.submittedAnswers[poiName] = { responses, referenceUrl, addressData };

    // Initialize completedPOIs array if missing
    this.dailyData.completedPOIs = this.dailyData.completedPOIs || [];

    // Track completed POI
    if (!this.dailyData.completedPOIs.includes(poiName)) {
        this.dailyData.completedPOIs.push(poiName);
    }

    try {
        console.log("Submitting data for:", poiName);
        const response = await fetch('/api/poi/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                poiName,
                responses,
                referenceUrl,
                addressData,
                timestamp: new Date().toISOString()
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error("Submission failed:", response.status, errorText);
            throw new Error(`Failed to submit POI data (Status: ${response.status})`);
        }

        const result = await response.json();
        console.log("Submission successful:", result);

        // Show success popup
        alert("Task submitted successfully!");

        // Update daily stats
        this.dailyData.completedTasks = (this.dailyData.completedTasks || 0) + 1;
        localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));

        // Check daily limit
        const dailyLimit = this.dailyData.dailyLimit || 3;
        if (this.dailyData.completedTasks >= dailyLimit) {
            console.log("Daily limit reached.");
            this.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
            localStorage.removeItem('currentPOIIndex');

            alert(`You have completed your daily limit of ${dailyLimit} POIs. Good job! Redirecting...`);
            setTimeout(() => {
                window.location.href = '/end';
            }, 1500);

            return result;
        }

        // Move to next POI
        const nextPoi = this.nextPOI();
        if (nextPoi) {
            console.log("Moving to next POI:", nextPoi['Official Name']);
            updateUIWithPOIData(nextPoi);
            // Reset submit button after successful navigation
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = 'Submit';
            }
        } else {
            console.log("All available POIs completed.");
            this.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(this.dailyData));
            localStorage.removeItem('currentPOIIndex');

            alert("You've gone through all available POIs for now! Great work.");
            setTimeout(() => {
                window.location.href = '/end';
            }, 1500);
        }

        return result;

    } catch (error) {
        console.error('Error during POI submission:', error);
        alert(`Error submitting data: ${error.message}. Please check your connection and try again.`);
        return null;

    } finally {
        // Reset submit button unless redirecting
        if (submitButton && this.dailyData.active) {
            submitButton.disabled = false;
            submitButton.textContent = 'Submit';
        }
    }
}

    nextPOI() {
        // Check if there are POIs left *after* the current one
        if (this.currentIndex < this.poiList.length - 1) {
            this.currentIndex++;
            // Store the updated index in localStorage
            localStorage.setItem('currentPOIIndex', this.currentIndex.toString());
            console.log('Advanced to next POI, index:', this.currentIndex);
            return this.poiList[this.currentIndex];
        } else {
            return null; // No more POIs in the list
        }
    }

    getCurrentPOI() {
        if (this.poiList.length > 0 && this.currentIndex < this.poiList.length) {
            return this.poiList[this.currentIndex];
        }
        return null; // No POI loaded or index out of bounds
    }

    // Get previously submitted answers for a POI if available (useful if implementing back button)
    getSubmittedAnswers(poiName) {
        return this.submittedAnswers[poiName] || null;
    }
}

// --- Global POI Manager Instance ---
let poiManager;

// --- Utility Functions ---

// Function to format coordinates in the desired format (lat, lng)
// Update the formatCoordinates function to handle separate lat/lng fields
function formatCoordinates(lat, lng) {
    if (lat === null || lng === null || lat === undefined || lng === undefined) return null;
    
    try {
        // Parse to float in case they're strings
        let latitude = parseFloat(lat);
        let longitude = parseFloat(lng);
        
        // Validate the coordinates
        if (isNaN(latitude) || isNaN(longitude) || 
            latitude < -90 || latitude > 90 || 
            longitude < -180 || longitude > 180) {
            throw new Error("Invalid coordinate values");
        }
        
        // Format to 5 decimal places and join with a comma and space
        return `${parseFloat(latitude.toFixed(5))}, ${parseFloat(longitude.toFixed(5))}`;
    } catch (error) {
        console.warn("Failed to format coordinates:", error);
        return null;
    }
}


// Update the updateUIWithPOIData function to use the new field names
function updateUIWithPOIData(poi) {
    if (!poi) {
        console.error("Cannot update UI: Invalid POI data provided.");
        alert("Error loading POI details. Redirecting...");
        window.location.href = '/end';
        return;
    }
    console.log("Updating UI for POI:", poi['Official Name']);

    // Update POI name, category, and address
    document.querySelector('h2').textContent = poi['Official Name'] || 'Unnamed POI';
    document.getElementById('primary-category').textContent = poi['Primary Category Name'] || 'Category Unknown';
    
    // Update address element with Unparsed Address
    const addressElement = document.getElementById('primary-category').nextElementSibling;
    if (addressElement) {
        // Check if Unparsed Address exists, if not, generate it from components
        let unparsedAddress = poi['Unparsed Address'];
        
        // If Unparsed Address is null but we have address components, combine them
        if (!unparsedAddress && poi.addressComponents) {
            unparsedAddress = combineAddressComponents(poi.addressComponents);
        }
        
        addressElement.textContent = `📍 ${unparsedAddress || 'Address not available'}`;
    }

    // Format and update coordinates from separate lat/lng fields
    const formattedCoords = formatCoordinates(poi['Display Latitude'], poi['Display Longitude']);
    const coordsDisplay = document.getElementById('coordinates');
    if (formattedCoords) {
        coordsDisplay.innerHTML = `📌 ${formattedCoords} <span class="copy-icon">(click to copy)</span>`;
        coordsDisplay.style.cursor = 'pointer';
        coordsDisplay.onclick = copyCoordinates;
        
        // Also populate the display coordinates field if it exists
        const displayCoordsInput = document.getElementById('display-coords');
        if (displayCoordsInput) {
            displayCoordsInput.value = formattedCoords;
        }
        
        // Populate separate lat/lng fields if they exist
        const latInput = document.getElementById('display-latitude');
        const lngInput = document.getElementById('display-longitude');
        if (latInput) latInput.value = poi['Display Latitude'];
        if (lngInput) lngInput.value = poi['Display Longitude'];
    } else {
        coordsDisplay.innerHTML = `📌 Coordinates not available`;
        coordsDisplay.style.cursor = 'default';
        coordsDisplay.onclick = null;
    }

    // Update POI location copy element
    const poiLocationDisplay = document.getElementById('poi-location');
    const addressText = poi['Unparsed Address'] || '';
    poiLocationDisplay.innerHTML = `🔍 Copy "${poi['Official Name'] || ''} ${addressText}" <span class="copy-icon">(click to copy)</span>`;
    poiLocationDisplay.onclick = copyPoiLocation;

    // --- Update Map Links ---
    const googleMapsLink = document.querySelector('.map-box:nth-child(1) .map-link');
    const mapCreatorLink = document.querySelector('.map-box:nth-child(2) .map-link');

    // Use Name + Address for Google Search query for better accuracy
    const searchQuery = `${poi['Official Name'] || ''}, ${poi['Unparsed Address'] || ''}`.trim();
    const encodedQuery = encodeURIComponent(searchQuery);
    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedQuery}`;
    googleMapsLink.href = googleMapsUrl;

    // Use coordinates for Map Creator if available
    if (poi['Display Latitude'] && poi['Display Longitude']) {
        try {
            const lat = parseFloat(poi['Display Latitude']);
            const lng = parseFloat(poi['Display Longitude']);
            // Validate lat/lng roughly
            if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
                const mapCreatorUrl = `https://mapcreator.here.com/?l=${lat},${lng},19,satellite`;
                mapCreatorLink.href = mapCreatorUrl;
                mapCreatorLink.classList.remove('disabled');
                mapCreatorLink.target = '_blank'; // Open in new tab
            } else {
                throw new Error("Invalid coordinate format");
            }
        } catch (e) {
            console.warn("Could not parse coordinates for Map Creator link:", e);
            mapCreatorLink.href = '#';
            mapCreatorLink.classList.add('disabled');
            mapCreatorLink.target = '';
        }
    } else {
        // Disable Map Creator link if no valid coords
        mapCreatorLink.href = '#';
        mapCreatorLink.classList.add('disabled');
        mapCreatorLink.target = '';
    }

    // --- Reset Form Elements ---
    document.querySelector('.search-input').value = ''; // Clear reference URL input
    document.querySelectorAll('.question-box .action-button').forEach(btn => {
        btn.classList.remove('selected-button'); // Deselect all Yes/No/Unknown buttons
    });

    // --- Reset Progress Bar ---
    updateProgress();
}

// Update the createAddressInputFields function to include separate lat/lng fields
function createAddressInputFields() {
    const addressFieldsContainer = document.getElementById('address-fields-container');
    if (!addressFieldsContainer) {
        console.warn("Address fields container not found in the DOM");
        return null;
    }
    
    // Clear existing fields
    addressFieldsContainer.innerHTML = '';
    
    // Create title
    const titleElement = document.createElement('h3');
    titleElement.textContent = 'Address Details';
    addressFieldsContainer.appendChild(titleElement);
    
    // Define fields to create with separate lat/lng fields
    const fields = [
        { id: 'house-number', label: 'House Number' },
        { id: 'street-name', label: 'Full Street Name' },
        { id: 'admin-level2', label: 'Admin Level 2' },
        { id: 'admin-level3', label: 'Admin Level 3' },
        { id: 'admin-level4', label: 'Admin Level 4' },
        { id: 'admin-level5', label: 'Admin Level 5' },
        { id: 'postal-code', label: 'Postal Code' },
        { id: 'country-code', label: 'Country Code' },
        { id: 'display-latitude', label: 'Display Latitude' },
        { id: 'display-longitude', label: 'Display Longitude' },
        { id: 'display-coords', label: 'Combined Coordinates (auto-generated)' }
    ];
    
    // Create form fields
    fields.forEach(field => {
        const fieldContainer = document.createElement('div');
        fieldContainer.className = 'field-container';
        
        const label = document.createElement('label');
        label.htmlFor = field.id;
        label.textContent = field.label;
        
        const input = document.createElement('input');
        input.type = 'text';
        input.id = field.id;
        input.className = 'address-input';
        
        // Make combined coordinates field read-only
        if (field.id === 'display-coords') {
            input.readOnly = true;
        }
        
        fieldContainer.appendChild(label);
        fieldContainer.appendChild(input);
        addressFieldsContainer.appendChild(fieldContainer);
    });
    
    // Add CSS styles
    const style = document.createElement('style');
    style.textContent = `
        #address-fields-container {
            margin-top: 15px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        #address-fields-container h3 {
            margin-top: 0;
            color: #333;
        }
        .field-container {
            margin-bottom: 10px;
        }
        .field-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .address-input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .address-input[readonly] {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }
    `;
    document.head.appendChild(style);
    
    return true;
}

// Update the collectAddressData function to handle separate lat/lng
function collectAddressData() {
    const addressData = {};
    
    // Only collect if fields exist
    
    return addressData;
}

// Add event listeners for the lat/lng fields
function setupLatLngEventListeners() {
    const latInput = document.getElementById('display-latitude');
    const lngInput = document.getElementById('display-longitude');
    const coordsInput = document.getElementById('display-coords');
    
    if (latInput && lngInput && coordsInput) {
        // Function to update combined coordinates when lat or lng changes
        const updateCombinedCoords = () => {
            const lat = latInput.value.trim();
            const lng = lngInput.value.trim();
            
            if (lat && lng) {
                const formattedCoords = formatCoordinates(lat, lng);
                if (formattedCoords) {
                    coordsInput.value = formattedCoords;
                    
                    // Also update the coordinates display
                    const coordsDisplay = document.getElementById('coordinates');
                    if (coordsDisplay) {
                        coordsDisplay.innerHTML = `📌 ${formattedCoords} <span class="copy-icon">(click to copy)</span>`;
                        coordsDisplay.style.cursor = 'pointer';
                        coordsDisplay.onclick = copyCoordinates;
                    }
                }
            } else {
                coordsInput.value = '';
            }
        };
        
        // Add blur event listeners to both fields
        latInput.addEventListener('blur', updateCombinedCoords);
        lngInput.addEventListener('blur', updateCombinedCoords);
    }
}

// Update setupEventListeners to include the lat/lng listeners
function setupEventListeners() {
    // Ensure address input fields exist
    createAddressInputFields();
    
    // Set up lat/lng event listeners
    setupLatLngEventListeners();

    // Rest of the event listener setup code...
    // [Existing code for setting up other event listeners]
}

// Update the copyCoordinates function to work with the new coords format
function copyCoordinates() {
    const coordsElement = document.getElementById("coordinates");
    // Extract coordinates after the pin emoji and space
    const coordsText = coordsElement.textContent.substring(coordsElement.textContent.indexOf(' ') + 1).trim();
    // Remove the copy icon text if present
    const finalCoords = coordsText.replace(/\(click to copy\)/i, '').trim();
    
    if (!finalCoords) {
        console.warn("No coordinates text found to copy.");
        return;
    }
    
    navigator.clipboard.writeText(finalCoords).then(() => {
        const tooltip = document.getElementById("tooltip");
        tooltip.classList.add("show-tooltip");
        setTimeout(() => tooltip.classList.remove("show-tooltip"), 1500); // Shorter duration
    }).catch(err => {
        console.error('Failed to copy coordinates: ', err);
        alert('Failed to copy coordinates. Your browser might not support this feature or requires permissions.');
    });
}

// Function to copy POI location (Name + Address)
function copyPoiLocation() {
    const poiName = document.querySelector('h2')?.textContent || '';
    // Find address more reliably, assuming it's the element after the category
    const addressElement = document.getElementById('primary-category')?.nextElementSibling;
    const address = addressElement?.textContent.replace('📍 ', '').trim() || '';
    const poiLocation = `${poiName} ${address}`.trim(); // Trim in case one is empty

    if (!poiLocation) {
        console.warn("No POI Name or Address found to copy.");
        return;
    }

    navigator.clipboard.writeText(poiLocation).then(() => {
        const poiTooltip = document.getElementById("poi-tooltip");
        poiTooltip.classList.add("show-tooltip");
        setTimeout(() => poiTooltip.classList.remove("show-tooltip"), 1500); // Shorter duration
    }).catch(err => {
        console.error('Failed to copy POI location: ', err);
        alert('Failed to copy location. Your browser might not support this feature or requires permissions.');
    });
}

// Function to create address input fields
function createAddressInputFields() {
    const addressFieldsContainer = document.getElementById('address-fields-container');
    if (!addressFieldsContainer) {
        console.warn("Address fields container not found in the DOM");
        return null;
    }
    
    // Clear existing fields
    addressFieldsContainer.innerHTML = '';
    
    // Create title
    const titleElement = document.createElement('h3');
    titleElement.textContent = 'Address Details';
    addressFieldsContainer.appendChild(titleElement);
    
    // Define fields to create
    const fields = [
        { id: 'house-number', label: 'House Number' },
        { id: 'street-name', label: 'Full Street Name' },
        { id: 'admin-level2', label: 'Admin Level 2' },
        { id: 'admin-level3', label: 'Admin Level 3' },
        { id: 'admin-level4', label: 'Admin Level 4' },
        { id: 'admin-level5', label: 'Admin Level 5' },
        { id: 'postal-code', label: 'Postal Code' },
        { id: 'country-code', label: 'Country Code' },
        { id: 'display-coords', label: 'Display Coordinates (lat, lng)' }
    ];
    
    // Create form fields
    fields.forEach(field => {
        const fieldContainer = document.createElement('div');
        fieldContainer.className = 'field-container';
        
        const label = document.createElement('label');
        label.htmlFor = field.id;
        label.textContent = field.label;
        
        const input = document.createElement('input');
        input.type = 'text';
        input.id = field.id;
        input.className = 'address-input';
        
        fieldContainer.appendChild(label);
        fieldContainer.appendChild(input);
        addressFieldsContainer.appendChild(fieldContainer);
    });
    
    // Add CSS styles
    const style = document.createElement('style');
    style.textContent = `
        #address-fields-container {
            margin-top: 15px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        #address-fields-container h3 {
            margin-top: 0;
            color: #333;
        }
        .field-container {
            margin-bottom: 10px;
        }
        .field-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .address-input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    `;
    document.head.appendChild(style);
    
    return true;
}

// Function to update UI with POI data
function updateUIWithPOIData(poi) {
    if (!poi) {
        console.error("Cannot update UI: Invalid POI data provided.");
        alert("Error loading POI details. Redirecting...");
        window.location.href = '/end';
        return;
    }
    console.log("Updating UI for POI:", poi['Official Name']);

    // Update POI name, category, and address
    document.querySelector('h2').textContent = poi['Official Name'] || 'Unnamed POI';
    document.getElementById('primary-category').textContent = poi.primary_category || 'Category Unknown';
    
    // Update address element
    const addressElement = document.getElementById('primary-category').nextElementSibling;
    if (addressElement) {
        addressElement.textContent = `📍 ${poi.address || 'Address not available'}`;
    }

    // Format and update coordinates
    const formattedCoords = formatCoordinates(poi['Display Latitude'], poi['Display Longitude']);
    const coordsDisplay = document.getElementById('coordinates');
    if (formattedCoords) {
        coordsDisplay.innerHTML = `📌 ${formattedCoords} <span class="copy-icon">(click to copy)</span>`;
        coordsDisplay.style.cursor = 'pointer';
        coordsDisplay.onclick = copyCoordinates;
        
        // Also populate the display coordinates field if it exists
        const displayCoordsInput = document.getElementById('display-coords');
        if (displayCoordsInput) {
            displayCoordsInput.value = formattedCoords;
        }
    } else {
        coordsDisplay.innerHTML = `📌 Coordinates not available`;
        coordsDisplay.style.cursor = 'default';
        coordsDisplay.onclick = null;
    }

    // Update POI location copy element
    const poiLocationDisplay = document.getElementById('poi-location');
    const addressText = poi.address || '';
    poiLocationDisplay.innerHTML = `🔍 Copy "${poi['Official Name'] || ''} ${addressText}" <span class="copy-icon">(click to copy)</span>`;
    poiLocationDisplay.onclick = copyPoiLocation;

    // --- Update Map Links ---
    const googleMapsLink = document.querySelector('.map-box:nth-child(1) .map-link');
    const mapCreatorLink = document.querySelector('.map-box:nth-child(2) .map-link');

    // Use Name + Address for Google Search query for better accuracy
    const searchQuery = `${poi['Official Name'] || ''}, ${poi.address || ''}`.trim();
    const encodedQuery = encodeURIComponent(searchQuery);
    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedQuery}`;
    googleMapsLink.href = googleMapsUrl;

    // Use coordinates for Map Creator if available
    if (formattedCoords) {
        try {
            const [lat, lng] = formattedCoords.split(',').map(coord => coord.trim());
            // Validate lat/lng roughly
            if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
                const mapCreatorUrl = `https://mapcreator.here.com/?l=${lat},${lng},19,satellite`;
                mapCreatorLink.href = mapCreatorUrl;
                mapCreatorLink.classList.remove('disabled');
                mapCreatorLink.target = '_blank'; // Open in new tab
            } else {
                throw new Error("Invalid coordinate format");
            }
        } catch (e) {
            console.warn("Could not parse coordinates for Map Creator link:", formattedCoords, e);
            mapCreatorLink.href = '#';
            mapCreatorLink.classList.add('disabled');
            mapCreatorLink.target = '';
        }
    } else {
        // Disable Map Creator link if no valid coords
        mapCreatorLink.href = '#';
        mapCreatorLink.classList.add('disabled');
        mapCreatorLink.target = '';
    }


    // --- Reset Form Elements ---
    document.querySelector('.search-input').value = ''; // Clear reference URL input
    document.querySelectorAll('.question-box .action-button').forEach(btn => {
        btn.classList.remove('selected-button'); // Deselect all Yes/No/Unknown buttons
    });

    // --- Reset Progress Bar ---
    updateProgress(); 
}

// Function to update progress based on answered questions
function updateProgress() {
    const questionBoxes = document.querySelectorAll('.question-box');
    const totalQuestions = questionBoxes.length;
    if (totalQuestions === 0) {
        document.querySelector('.progress-bar').style.width = '0%';
        document.querySelector('.progress-text').textContent = '0%';
        return;
    }

    let answeredQuestions = 0;
    questionBoxes.forEach(box => {
        if (box.querySelector('.selected-button')) {
            answeredQuestions++;
        }
    });

    const progressPercent = Math.round((answeredQuestions / totalQuestions) * 100);

    document.querySelector('.progress-bar').style.width = `${progressPercent}%`;
    document.querySelector('.progress-text').textContent = `${progressPercent}%`;

    // Enable/disable submit button based on progress
    const submitButton = document.querySelector('.submit-button');
    if (submitButton) {
        submitButton.disabled = (answeredQuestions !== totalQuestions);
    }
}

// Setup all event listeners
function setupEventListeners() {
    // Ensure address input fields exist
    createAddressInputFields();

    // Add button selection functionality for all action buttons (Yes/No/Unknown)
    document.querySelectorAll('.question-box .action-button').forEach(button => {
        button.addEventListener('click', function() {
            // Remove selected class from siblings within the same button group
            this.parentNode.querySelectorAll('.action-button').forEach(sib => {
                if (sib !== this) sib.classList.remove('selected-button');
            });

            // Add selected class to clicked button (ensure it's always selected)
            this.classList.add('selected-button');

            // Update progress bar
            updateProgress();
        });
    });

    // Submit button event listener
    const submitButton = document.querySelector('.submit-button');
    if (submitButton) {
        submitButton.addEventListener('click', async () => {
            const currentPOI = poiManager.getCurrentPOI();
            if (!currentPOI) {
                alert("Error: No current POI loaded. Cannot submit.");
                return;
            }

            const poiName = currentPOI['Official Name'];
            const referenceUrl = document.querySelector('.search-input').value.trim();
            
            // Collect address data
            const addressData = collectAddressData();

            // Collect responses from question boxes
            const responses = [];
            let allAnswered = true;
            document.querySelectorAll('.question-box').forEach(box => {
                const question = box.querySelector('div:first-child').textContent.trim();
                const selectedButton = box.querySelector('.selected-button');
                let answer = 'Not answered'; // Default if nothing selected

                if (selectedButton) {
                    if (selectedButton.classList.contains('yes')) answer = 'Yes';
                    else if (selectedButton.classList.contains('no')) answer = 'No';
                    else if (selectedButton.classList.contains('dont-know')) answer = 'Unknown';
                } else {
                    allAnswered = false; // Mark that at least one is unanswered
                }

                responses.push({ question, answer });
            });

            // Validate Reference URL (optional - basic check)
            if (referenceUrl && !referenceUrl.toLowerCase().startsWith('http')) {
                if (!confirm("The Reference URL doesn't look like a valid web link (doesn't start with http). Submit anyway?")) {
                    return; // Stop submission if user cancels
                }
            }

            // Check if all questions are answered - confirm if not
            if (!allAnswered) {
                if (!confirm("Warning: Not all questions have been answered. Are you sure you want to submit?")) {
                    return; // Stop submission if user cancels
                }
            }

            // Disable button to prevent double submission
            submitButton.disabled = true;
            submitButton.textContent = 'Submitting...';

            // Submit data using the manager
            const result = await poiManager.submitPOIData(poiName, responses, referenceUrl, addressData);

            // Re-enable button only if submission failed and we are staying on the same POI
            if (!result || (result && result.status !== 'success' && !window.location.href.endsWith('/end'))) {
                submitButton.disabled = false;
                submitButton.textContent = 'Submit';
            }
        });
    } else {
        console.error("Submit button not found!");
    }
    
    // Add event listener for coordinates synchronization
    const displayCoordsInput = document.getElementById('display-coords');
    if (displayCoordsInput) {
        displayCoordsInput.addEventListener('blur', function() {
            // Format and validate the coordinates
            const formattedCoords = formatCoordinates(this.value);
            if (formattedCoords) {
                this.value = formattedCoords;
                
                // Update the coordinates display
                const coordsDisplay = document.getElementById('coordinates');
                if (coordsDisplay) {
                    coordsDisplay.innerHTML = `📌 ${formattedCoords} <span class="copy-icon">(click to copy)</span>`;
                    coordsDisplay.style.cursor = 'pointer';
                    coordsDisplay.onclick = copyCoordinates;
                }
            }
        });
    }
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', async () => {
    console.log("DOM fully loaded and parsed");

    // Instantiate the manager - this also loads dailyData and potentially starts timer
    poiManager = new POIDataManager();

    // Ensure daily data was loaded and session is active before proceeding
    if (!poiManager.dailyData || !poiManager.dailyData.active) {
        console.log("Initialization halted: Session not active or data missing.");
        return;
    }

    try {
        // Fetch POI names
        const poiList = await poiManager.fetchPOINames();

        // Check if we received any POIs
        if (!poiList || poiList.length === 0) {
            console.warn('No POIs available in the list.');
            alert('No Points of Interest are currently available for processing. Please check back later.');
            // Mark session inactive and redirect
            poiManager.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(poiManager.dailyData));
            window.location.href = '/end';
            return;
        }

        // Load the first POI into the UI
        const firstPoi = poiManager.getCurrentPOI();
        if (firstPoi) {
            updateUIWithPOIData(firstPoi);
        } else {
            console.error("Failed to get the first POI from the fetched list.");
            alert("Error loading the first Point of Interest.");
            poiManager.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(poiManager.dailyData));
            window.location.href = '/end';
            return;
        }

        console.log('Loaded Initial POI:', firstPoi['Official Name']);

        // Set up all event listeners for buttons, etc.
        setupEventListeners();

        // Initial progress update
        updateProgress();

        console.log("Initialization complete. Ready for user input.");

    } catch (error) {
        // Catch any critical errors during the async initialization process
        console.error('Critical Initialization error:', error);
        alert('A critical error occurred during setup: ' + error.message + "\nPlease try refreshing the page.");
        // Optional: Attempt to end session gracefully
        if (poiManager && poiManager.dailyData) {
            poiManager.dailyData.active = false;
            localStorage.setItem('poiDailyData', JSON.stringify(poiManager.dailyData));
        }
    }
});